<?php
return array(
	'D3ModelViewer.meta.name'				=> 'D3ModelViewer',
	'D3ModelViewer.meta.title'				=> 'D3ModelViewer',
	'D3ModelViewer.meta.desc'				=> 'D3ModelViewer fbx,obj,gltf,glb,bvh,3ds,ply,stl,usdz,3dm files online without a third-party interface',
);