<?php
return array(
	'D3ModelViewer.meta.name'				=> 'D3模型查看器',
	'D3ModelViewer.meta.title'				=> 'D3模型查看器，在线查看你的模型',
	'D3ModelViewer.meta.desc'				=> 'D3模型查看器，无需借助第三方接口即可在线查看 fbx,obj,gltf,glb,bvh,3ds,ply,stl,usdz,3dm 文件',
);